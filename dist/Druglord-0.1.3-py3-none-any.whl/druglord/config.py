class Config:
    SELENIUM_IMPLICIT_WAIT = 20
